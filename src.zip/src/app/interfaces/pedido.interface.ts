export interface PedidoMesa1 {
  id: string;
  pizza: string;
  mesa: string;
}

export interface PedidoMesa2 {
  id: string;
  pizza: string;
  mesa: string;
}

export interface PedidoMesa3 {
  id: string;
  pizza: string;
  mesa: string;
}

export interface PedidoMesa4 {
  id: string;
  pizza: string;
  mesa: string;
}
